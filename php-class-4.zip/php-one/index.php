<?php
$text="mahmud Hasan Manik";
echo strlen($text);
echo '<br>';
echo ucfirst($text);

echo '<br>';
// mark sheet
$mark=34;
if($mark<33){
    echo'F';
}else{
    echo'Pass';
}
?>